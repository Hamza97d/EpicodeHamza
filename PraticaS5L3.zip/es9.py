"""Scrivere una funzione che in input acquisisce una lista di numeri e un numero K; in output, 
dovra restituire la media di tutti i numeri nella lista maggiori o uguali a K; 
se non ce ne dovesse essere nessuno, dovra stampare a schermo un messaggio adeguato."""
        
def media(lista_numeri,k):  
  lista_somma=[]
  for elemento in lista_numeri:
    if elemento >= k:
      lista_somma.append(elemento) 
  len_lista=len(lista_somma)
  somma_lista=sum(lista_somma)
  return somma_lista/len_lista   


lista_numeri = [2, 15, 2, 36, 12, 16, 7, 8, 9, 15, 25, 4, 1, 5]
print(media(lista_numeri, 10))
