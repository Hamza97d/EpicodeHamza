#es7
"""Scrivere una funzione che, data una lista di numeri, fornisca in output i tre numeri piu grandi; 
gestire il caso in cui la lista sia piu corta di tre, e quando uno o piu dei numeri selezionati sono uguali. """


def ultimi_tre_numeri(lista_numeri):
  lista_numeri.sort()
  lunghezza_lista= len(lista_numeri)
  indice=0
  lista_simili=[]
  if len(lista_numeri) > 3:
    lista_numeri.sort()
    print(lista_numeri[-3:])
  else:
    print("Errore, inserire piu numeri.")
  while indice < lunghezza_lista: 
      if lista_numeri[indice] in lista_simili: 
          print("Errore numeri uguali")
          break 
      else: 
          lista_simili.append(lista_numeri[indice])
          indice += 1

  
    
lista_numeri = [2, 4, 12, 14, 16, 22, 45, 49]
    
ultimi_tre_numeri(lista_numeri)