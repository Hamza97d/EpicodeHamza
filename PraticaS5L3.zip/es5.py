#es5
#Con un ciclo, e usando il metodo .values(), stampiamo a video tutte le auto che non sono una #Multipla. 

dizionario_auto = {"Ada": "Punto", "Ben": "Multipla", "Charlie": "Golf", "Debbie": "107"} 
valori= dizionario_auto.values()

for elemento in valori:
  if elemento != "Multipla": 
    print(elemento)