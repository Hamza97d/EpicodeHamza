#es2

for numero in range(21):
  print(numero)
  