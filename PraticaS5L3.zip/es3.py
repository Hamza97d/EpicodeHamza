#es3

for numero in range(10): 
  print(2**numero)