#es4

dizionario_intero={"Ada": "Punto", "Ben": "Multipla", "Charlie": "Golf", "Debbie": "107"}    

print(dizionario_intero)
print(dizionario_intero["Debbie"])