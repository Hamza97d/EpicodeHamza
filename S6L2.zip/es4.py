


import numpy as np


dati= np.array([1,1,1,1,5,1,1,1,20,-4,0,42])

dati_matrice= dati.reshape(3,4)

print(dati_matrice)