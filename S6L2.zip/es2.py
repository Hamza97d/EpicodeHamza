


import numpy as np


#Abbiamo il seguente array NumPy: 

linear_data = np.array([x for x in range(27)]) 


#Lo ridimensioniamo mediante il metodo .reshape(): 

reshaped_data = linear_data.reshape((3, 3, 3))

#Quante dimensioni ha il nuovo array? Come facciamo per accedere ai singoli elementi?

print(linear_data.ndim)
print(reshaped_data.ndim)
print(reshaped_data[2,2,1])