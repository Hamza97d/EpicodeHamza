


import numpy as np


array_numeri= np.array([10, 22, 21, 8, 9, 9, 42, 3, 18,11,5,4,30,12,29,37,31,7,2,26,8,6,4,33,15])
new_list=[]
for x in array_numeri:
    a=(x-array_numeri.min())/(array_numeri.max()-array_numeri.min())
    new_list.append(a)
    
ar_list= np.array([new_list])

print(type(ar_list))


ar_list= ar_list.reshape(5,5)

print(ar_list)
