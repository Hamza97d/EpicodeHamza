


import numpy as np

#Trasformiamo la lista  1

mat = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14]] 

mat = np.array(mat)
# possiamo accedere al al array come con la lista es mat[0,4] va alla prima lista e prendere il il suo 4 elemento
print(mat[0,4])

