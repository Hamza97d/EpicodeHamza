#Creazione di una classe Cerchio: Definisci una classe Cerchio con un 
#attributo raggio e metodi per calcolare l'area e la circonferenza.      

class cerchio: 
    def __init__(self, r):
        
      self.raggio= r
    
    def calcolo_area(self):
       area= 3.14 * int(self.raggio)**2
       print("l'area del cerchio e: ", area)
    
    def calcolo_circonferenza(self):
       circonferenza= 2* 3.14 * int(self.raggio)
       print("la circonferenza del cerchio e:", circonferenza)
       

dati_cerchio= cerchio(6)

dati_cerchio.calcolo_circonferenza()