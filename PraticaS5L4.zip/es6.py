#classe per trovare il numero piu grande

class TrovaNumeroPiuGrande:
    def __init__(self, numeri):
        self.numeri = numeri

    def trova_numero_piu_grande(self):
        if not self.numeri:
            return None  

        numero_piu_grande = self.numeri[0]
        for numero in self.numeri:
            if numero > numero_piu_grande:
                numero_piu_grande = numero

        return numero_piu_grande


# Esempio di utilizzo
lista_di_numeri = [10, 5, 8, 15, 3]
trova_numero = TrovaNumeroPiuGrande(lista_di_numeri)
numero_maggiore = trova_numero.trova_numero_piu_grande()

if numero_maggiore is not None:
    print(f"Il numero piu grande e: {numero_maggiore}")
else:
    print("La lista e vuota.")