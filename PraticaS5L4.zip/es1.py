""" Creazione di una classe Persona: Crea una classe Persona con attributi 
come nome, cognome e eta. Inserisci un metodo per stampare le informazioni
della persona."""


class persona:
    def __init__(self, n, c, e):
        
        self.nome= n
        self.cognome= c
        self.eta= e
    
    def stampa(self):
        print(self.nome, self.cognome, self.eta)

dati_persona= persona("Hamza","mahmoudi","26")

persona.stampa(dati_persona)