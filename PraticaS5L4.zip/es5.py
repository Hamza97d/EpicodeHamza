#Gestione di una classe Prodotto: Crea una classe Prodotto con attributi come nome, 
#prezzo e quantità disponibile. Aggiungi metodi per calcolare il costo totale e verificare la #disponibilita.

class prodotto: 
    def __init__(self, n, p, q):
        
      self.nome= n
      self.prezzo= p
      self.quantita_disponibile= q
      
    def costo_totale(self, quantita):
       print("Importo totale transazione $:", self.prezzo* quantita )
    
    def disponibile(self, quantita):
       if quantita < self.quantita_disponibile:
          print("Quantita richiesta disponibile")
       else: 
          print("Quantita richiesta non disponibile")
          

richiesta_prodotto=  prodotto("Power1",25.65, 100)

richiesta_prodotto.disponibile(50)