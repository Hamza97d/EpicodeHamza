#Simulazione di un Conto Bancario: Crea una classe ContoBancario 
#con attributi saldo e metodo per depositare e prelevare denaro. 

class contoBancario:
  def __init__(self, s):
    
    self.saldo= s
    
  def deposito(self, dep):
    self.saldo= self.saldo+ dep
    print("Hai depositato sul tuo conto $:", dep, "\nSaldo attuale $:", self.saldo)
  def prelevo(self, pre):
    self.saldo= self.saldo- pre 
    print("Hai prelevato sul tuo conto $:", pre, "\nSaldo attuale $:", self.saldo)
    

dati_conto= contoBancario(200)
dati_conto.deposito(int(input("Quanto vuoi depositare?")))
dati_conto.prelevo(int(input("Quanto vuoi prelevare?")))