"""Gestione di una classe Libro: Creare una classe Libro con attributi 
come titolo, autore e anno di pubblicazione. 
Aggiungi un metodo per verificare se il libro e recente. """


class libro:
  def __init__(self, to, ae, aop):
    
    self.titolo= to
    self.autore= ae
    self.anno_pubblicazione= aop
    
  def recente(self):
    if int(self.anno_pubblicazione) >= 2023:
      print("il libro e recente")
    else: 
      print("il libro non e recente")  


dati_libro= libro("Introduzione a Python", "Nello Rizzo", "2024")

libro.recente(dati_libro)