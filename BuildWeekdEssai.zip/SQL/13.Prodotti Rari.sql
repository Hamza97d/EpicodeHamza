/* 13.	Prodotti Rari:
○	Domanda: Identifica i prodotti con una quantità disponibile inferiore alla media.
*/
WITH MediaQuantita AS (
    SELECT
        AVG(QuantitaDisponibile) AS MediaQuantita
    FROM
        Prodotti
)

SELECT
    ProdottoID,
    NomeProdotto,
    Categoria,
    QuantitaDisponibile
FROM
    Prodotti
JOIN
    MediaQuantita
WHERE
    QuantitaDisponibile < MediaQuantita.MediaQuantita;
