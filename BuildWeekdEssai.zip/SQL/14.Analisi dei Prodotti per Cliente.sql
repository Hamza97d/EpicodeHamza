/* 14.	Analisi dei Prodotti per Cliente:
○	Domanda: Per ogni cliente, elenca i prodotti acquistati e il totale speso.
*/

SELECT
    C.ClienteID,
    C.NomeCliente,
    GROUP_CONCAT(CONCAT('n. ',T.QuantitaAcquistata, ' ', P.NomeProdotto) SEPARATOR ', ') AS ProdottiAcquistati,
    SUM(T.QuantitaAcquistata * P.Prezzo) AS TotaleSpeso
FROM
    Transazioni T
JOIN
    Clienti C ON T.ClienteID = C.ClienteID
JOIN
    Prodotti P ON T.ProdottoID = P.ProdottoID
GROUP BY
    C.ClienteID, C.NomeCliente
ORDER BY
    C.ClienteID;
