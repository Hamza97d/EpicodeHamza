/* 4.	Valore medio della transazione:
○	Domanda: Calcola il valore medio di ogni transazione.
*/
SELECT
    AVG(ImportoTransazione) AS ValoreMedioTransazione
FROM
    Transazioni;
