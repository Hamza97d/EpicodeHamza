/* 1.	Analisi delle Vendite Mensili:
○	Domanda: Trova il totale delle vendite per ogni mese.
*/

SELECT 
    MONTH(DataTransazione) AS Mese,
    YEAR(DataTransazione) AS Anno,
    SUM(ImportoTransazione) AS TotaleVendite
FROM 
    transazioni
GROUP BY 
    YEAR(DataTransazione), MONTH(DataTransazione)
ORDER BY 
    Anno, Mese;
    SELECT
    MONTH(DataTransazione) AS Mese,
	YEAR(DataTransazione) AS Anno,
    SUM(QuantitaAcquistata) AS TotaleQuantita
FROM
    Transazioni
GROUP BY 
    YEAR(DataTransazione), MONTH(DataTransazione)
ORDER BY 
    Anno, Mese;


