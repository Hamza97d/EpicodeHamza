/* 6.	Cliente Fedele:
○	Domanda: Identifica il cliente con il maggior valore totale di acquisti.
*/
SELECT
    C.ClienteID,
    C.NomeCliente,
    SUM(P.Prezzo * T.QuantitaAcquistata) AS ValoreTotaleAcquisti
FROM
    Clienti C
JOIN
    Transazioni T ON C.ClienteID = T.ClienteID
JOIN
    Prodotti P ON T.ProdottoID = P.ProdottoID
GROUP BY
    C.ClienteID, C.NomeCliente
ORDER BY
    ValoreTotaleAcquisti DESC
LIMIT 1;
