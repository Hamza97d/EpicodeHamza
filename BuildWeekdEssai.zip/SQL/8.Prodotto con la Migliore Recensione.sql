/*8.	Prodotto con la Migliore Recensione:
○	Domanda: Trova il prodotto con la recensione media più alta.
*/

WITH MediaRecensioni AS (
    SELECT
        P.ProdottoID,
        P.NomeProdotto,
        AVG(R.Rating) AS MediaRecensione
    FROM
        Prodotti P
    JOIN
        recensioni R ON P.ProdottoID = R.ProdottoID
    GROUP BY
        P.ProdottoID, P.NomeProdotto
)
SELECT
    ProdottoID,
    NomeProdotto,
    MediaRecensione
FROM
    MediaRecensioni
WHERE
    MediaRecensione = (SELECT MAX(MediaRecensione) FROM MediaRecensioni);