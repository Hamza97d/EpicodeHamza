/* 16.	Analisi dei Prodotti in Magazzino:
○	Domanda: Trova la quantità totale di prodotti disponibili in magazzino.
*/

SELECT
    SUM(QuantitaDisponibile) AS QuantitaTotaleInMagazzino
FROM
    Prodotti;
SELECT
    Categoria,
    SUM(QuantitaDisponibile) AS QuantitaTotaleInMagazzinoPerCategoria
FROM
    Prodotti
GROUP BY
    Categoria;
