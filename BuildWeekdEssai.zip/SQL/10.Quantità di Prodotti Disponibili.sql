/* 10.	Quantità di Prodotti Disponibili:
○	Domanda: Determina la quantità media disponibile per categoria di prodotto.
*/
SELECT
    Categoria,
    AVG(QuantitaDisponibile) AS QuantitaMediaDisponibile
FROM
    Prodotti
GROUP BY
    Categoria;
