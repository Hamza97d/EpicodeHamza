/* 15.	Miglior Mese per le Vendite:
○	Domanda: Identifica il mese con il maggior importo totale delle vendite.
*/

SELECT
    EXTRACT(YEAR FROM DataTransazione) AS Anno,
    EXTRACT(MONTH FROM DataTransazione) AS Mese,
    SUM(ImportoTransazione) AS ImportoTotaleVendite
FROM
    Transazioni
GROUP BY
    Anno, Mese
HAVING
    SUM(ImportoTransazione) = (
        SELECT
            MAX(TotaleMensile)
        FROM (
            SELECT
                EXTRACT(YEAR FROM DataTransazione) AS Anno,
                EXTRACT(MONTH FROM DataTransazione) AS Mese,
                SUM(ImportoTransazione) AS TotaleMensile
            FROM
                Transazioni
            GROUP BY
                Anno, Mese
        ) AS TotaleMensilePerMese
    );

SELECT
    EXTRACT(YEAR FROM DataTransazione) AS Anno,
    EXTRACT(MONTH FROM DataTransazione) AS Mese,
    SUM(QuantitaAcquistata * Prezzo) AS ImportoTotaleVendite
FROM
    Transazioni T
JOIN
    Prodotti P ON T.ProdottoID = P.ProdottoID
GROUP BY
    Anno, Mese
HAVING
    SUM(QuantitaAcquistata * Prezzo) = (
        SELECT
            MAX(TotaleMensile)
        FROM (
            SELECT
                EXTRACT(YEAR FROM DataTransazione) AS Anno,
                EXTRACT(MONTH FROM DataTransazione) AS Mese,
                SUM(QuantitaAcquistata * Prezzo) AS TotaleMensile
            FROM
                Transazioni T
            JOIN
                Prodotti P ON T.ProdottoID = P.ProdottoID
            GROUP BY
                Anno, Mese
        ) AS TotaleMensilePerMese
    );
