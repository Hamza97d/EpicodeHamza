/* 3.	Analisi Cliente:
○	Domanda: Trova il cliente che ha effettuato il maggior numero di acquisti.
*/
WITH NumeroAcquistiCliente AS (
    SELECT
        C.ClienteID,
        C.NomeCliente,
        COUNT(T.TransazioneID) AS NumeroAcquisti
    FROM
        Clienti C
    JOIN
        Transazioni T ON C.ClienteID = T.ClienteID
    GROUP BY
        C.ClienteID, C.NomeCliente
)
SELECT
    ClienteID,
    NomeCliente,
    NumeroAcquisti
FROM
    NumeroAcquistiCliente
WHERE
    NumeroAcquisti = (SELECT MAX(NumeroAcquisti) FROM NumeroAcquistiCliente);

WITH NumeroProdottiCliente AS (
    SELECT
        C.ClienteID,
        C.NomeCliente,
        SUM(T.QuantitaAcquistata) AS NumeroProdottiAcquistati
    FROM
        Clienti C
    JOIN
        Transazioni T ON C.ClienteID = T.ClienteID
    GROUP BY
        C.ClienteID, C.NomeCliente
)
SELECT
    ClienteID,
    NomeCliente,
    NumeroProdottiAcquistati
FROM
    NumeroProdottiCliente
WHERE
    NumeroProdottiAcquistati = (SELECT MAX(NumeroProdottiAcquistati) FROM NumeroProdottiCliente);


