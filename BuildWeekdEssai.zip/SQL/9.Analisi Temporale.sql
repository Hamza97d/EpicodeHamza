/* 9.	Analisi Temporale:
○	Domanda: Calcola la variazione percentuale nelle vendite rispetto al mese precedente.
*/
SELECT
    EXTRACT(MONTH FROM DataTransazione) AS Mese,
    SUM(ImportoTransazione) AS VenditeMese,
    LAG(SUM(ImportoTransazione)) OVER (ORDER BY EXTRACT(MONTH FROM DataTransazione)) AS VenditeMesePrecedente,
    CASE
        WHEN LAG(SUM(ImportoTransazione)) OVER (ORDER BY EXTRACT(MONTH FROM DataTransazione)) IS NOT NULL THEN
            ((SUM(ImportoTransazione) - LAG(SUM(ImportoTransazione)) OVER (ORDER BY EXTRACT(MONTH FROM DataTransazione))) / LAG(SUM(ImportoTransazione)) OVER (ORDER BY EXTRACT(MONTH FROM DataTransazione))) * 100
        ELSE
            NULL
    END AS VariazionePercentuale
FROM
    Transazioni
GROUP BY
    EXTRACT(MONTH FROM DataTransazione)
ORDER BY
    Mese;
    
    
