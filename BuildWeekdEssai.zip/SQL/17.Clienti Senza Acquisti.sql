/* 17.	Clienti Senza Acquisti:
○	Domanda: Identifica i clienti che non hanno effettuato alcun acquisto.
*/

SELECT
    C.ClienteID,
    C.NomeCliente,
    C.Email,
    C.DataRegistrazione
FROM
    Clienti C
LEFT JOIN
    Transazioni T ON C.ClienteID = T.ClienteID
WHERE
    T.TransazioneID IS NULL;
