/* 5.	Analisi Categoria Prodotto:
○	Domanda: Determina la categoria di prodotto con il maggior numero di vendite.
*/
SELECT
    P.Categoria,
    SUM(T.QuantitaAcquistata) AS TotaleQuantitaVendute
FROM
    Prodotti P
JOIN
    Transazioni T ON P.ProdottoID = T.ProdottoID
GROUP BY
    P.Categoria
ORDER BY
    TotaleQuantitaVendute DESC
LIMIT 1;
