/* 12.	Analisi dei Clienti:
○	Domanda: Calcola il numero medio di clienti registrati al mese.
*/
SELECT
    EXTRACT(YEAR FROM DataRegistrazione) AS Anno,
    COUNT(DISTINCT ClienteID) / COUNT(DISTINCT EXTRACT(MONTH FROM DataRegistrazione)) AS MediaMensileClienti
FROM
    Clienti
GROUP BY
    Anno
ORDER BY
    Anno;
    