/* 11.	Analisi Spedizioni:
○	Domanda: Trova il metodo di spedizione più utilizzato.
*/

SELECT
    MetodoSpedizione,
    COUNT(*) AS NumeroUtilizzo
FROM
    Spedizioni
GROUP BY
    MetodoSpedizione
ORDER BY
    NumeroUtilizzo DESC
LIMIT 1;
