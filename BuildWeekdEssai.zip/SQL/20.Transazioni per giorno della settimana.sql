/* 20.	Transazioni per giorno della settimana
Mostra come sono distribuite le transazioni sui giorni della settimana
*/

SELECT
    DAYOFWEEK(DataTransazione) AS NumeroGiorno,
    CASE DAYOFWEEK(DataTransazione)
        WHEN 1 THEN 'Domenica'
        WHEN 2 THEN 'Lunedì'
        WHEN 3 THEN 'Martedì'
        WHEN 4 THEN 'Mercoledì'
        WHEN 5 THEN 'Giovedì'
        WHEN 6 THEN 'Venerdì'
        WHEN 7 THEN 'Sabato'
    END AS NomeGiorno,
    COUNT(*) AS NumeroTransazioni,
    (COUNT(*) / (SELECT COUNT(*) FROM Transazioni)) * 100 AS PercentualeTransazioni
FROM Transazioni
GROUP BY NumeroGiorno, NomeGiorno
ORDER BY NumeroGiorno;

