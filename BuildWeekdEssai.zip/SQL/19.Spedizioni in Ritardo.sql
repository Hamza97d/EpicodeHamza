/* 19.	Spedizioni in Ritardo:
○	Domanda: Trova la percentuale di spedizioni con "In Consegna" rispetto al totale.
*/

SELECT
    COUNT(*) AS TotaleSpedizioni,
    SUM(CASE WHEN StatusConsegna = 'In Consegna' THEN 1 ELSE 0 END) AS SpedizioniInConsegna,
    (SUM(CASE WHEN StatusConsegna = 'In Consegna' THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS PercentualeInConsegna
FROM
    Spedizioni;
