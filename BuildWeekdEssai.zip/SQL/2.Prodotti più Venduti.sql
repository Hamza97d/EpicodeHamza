/*2.	Prodotti più Venduti:
○	Domanda: Identifica i tre prodotti più venduti e la loro quantità venduta.
*/

SELECT 
    p.NomeProdotto,
    SUM(t.QuantitaAcquistata) AS QuantitaVenduta
FROM 
    transazioni t
JOIN 
    prodotti p ON t.ProdottoID = p.ProdottoID
GROUP BY 
    p.NomeProdotto
ORDER BY 
    QuantitaVenduta DESC
LIMIT 3;
