/*21.	Transazioni per mese
Mostra come sono distribuite le transazioni sui mesi
*/
SELECT
    MONTH(DataTransazione) AS NumeroMese,
    CASE MONTH(DataTransazione)
        WHEN 1 THEN 'Gennaio'
        WHEN 2 THEN 'Febbraio'
        WHEN 3 THEN 'Marzo'
        WHEN 4 THEN 'Aprile'
        WHEN 5 THEN 'Maggio'
        WHEN 6 THEN 'Giugno'
        WHEN 7 THEN 'Luglio'
        WHEN 8 THEN 'Agosto'
        WHEN 9 THEN 'Settembre'
        WHEN 10 THEN 'Ottobre'
        WHEN 11 THEN 'Novembre'
        WHEN 12 THEN 'Dicembre'
    END AS NomeMese,
    COUNT(*) AS NumeroTransazioni,
    (COUNT(*) / (SELECT COUNT(*) FROM Transazioni)) * 100 AS PercentualeTransazioni
FROM Transazioni
GROUP BY NumeroMese, NomeMese
ORDER BY NumeroMese;
