/* 18.	Analisi Annuale delle Vendite:
○	Domanda: Calcola il totale delle vendite per ogni anno.
*/
SELECT
    EXTRACT(YEAR FROM DataTransazione) AS Anno,
    SUM(ImportoTransazione) AS TotaleVendite
FROM
    Transazioni
GROUP BY
    Anno
ORDER BY
    Anno;
SELECT
    EXTRACT(YEAR FROM T.DataTransazione) AS Anno,
    SUM(T.QuantitaAcquistata * P.Prezzo) AS TotaleVendite
FROM
    Transazioni T
JOIN
    Prodotti P ON T.ProdottoID = P.ProdottoID
GROUP BY
    Anno
ORDER BY
    Anno;
