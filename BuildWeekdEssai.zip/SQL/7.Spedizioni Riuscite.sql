/* 7.	Spedizioni Riuscite:
○	Domanda: Calcola la percentuale di spedizioni con "Consegna Riuscita".
*/
SELECT
    COUNT(*) AS TotaleSpedizioni,
    SUM(CASE WHEN StatusConsegna = 'Consegna Riuscita' THEN 1 ELSE 0 END) AS SpedizioniConsegnaRiuscita,
    (SUM(CASE WHEN StatusConsegna = 'Consegna Riuscita' THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS PercentualeConsegnaRiuscita
FROM
    Spedizioni;
