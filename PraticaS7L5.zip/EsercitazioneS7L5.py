# -*- coding: utf-8 -*-
# -*- coding: latin-1 -*-


import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import StandardScaler
import seaborn as sns


climatico = pd.read_csv("dataset_climatico.csv", encoding='utf-8')

climatico= climatico.dropna()
#print(climatico.describe())

climaticon = ['data_osservazione', 'temperatura_media', 'precipitazioni', 'umidita', 'velocita_vento', 'stazione meteorologica']
climatico.columns = climaticon



# Seleziona colonne da normalizzare
columns_to_normalize = ['temperatura_media', 'precipitazioni', 'umidita', 'velocita_vento']

# Inizializza lo StandardScaler
scaler = StandardScaler()

# Applica la normalizzazione Z-score alle colonne selezionate
climatico[columns_to_normalize] = scaler.fit_transform(climatico[columns_to_normalize])

#climatico.to_csv('climatico_normalizzato.csv', index=False)


# Calcola statistiche descrittive
desc_stats = climatico[columns_to_normalize].describe()

# Stampa le statistiche descrittive
#print("Statistiche descrittive:")
#print(desc_stats)

# Crea grafici per visualizzare la distribuzione di ciascuna variabile normalizzata

# Istogrammi
climatico[columns_to_normalize].hist(bins=20, figsize=(12, 8))
plt.suptitle('Distribuzione delle Variabili Normalizzate', y=0.95)
#plt.show()

# Box plots
plt.figure(figsize=(12, 8))
sns.boxplot(data=climatico[columns_to_normalize])
plt.title('Box Plot delle Variabili Normalizzate')
#plt.show()







# Assume che tu abbia gi� eseguito la normalizzazione come descritto in precedenza
# climatico � il DataFrame normalizzato

# Calcola la matrice di correlazione
correlation_matrix = climatico[columns_to_normalize].corr()

# Crea una heatmap per visualizzare la correlazione
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
plt.title('Matrice di Correlazione tra Variabili Meteorologiche Normalizzate')
plt.show()




