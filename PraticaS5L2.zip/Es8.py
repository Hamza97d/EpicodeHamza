#Memorizza e stampa tutti i divisori di un numero dato in input.

numero= int(input("Digita numero: "))
divisori = []
i = 2
while i <= numero:
    if numero % i == 0:
      divisori.append(i) #Aggiunge il divisore i alla lista divisori.
      numero //= i #Aggiorna il valore di numero dividendo per i. Questo passo è importante per trovare tutti i divisori del numero, poiché stiamo riducendo progressivamente il numero cercando i suoi divisori primi.
    else:
      i += 1
print(divisori)
