"""Stampare ogni carattere della stringa, uno su ogni riga, 
utilizzando un costrutto while."""

nome_scuola= "Epicode"
lunghezza_scuola= len(nome_scuola)
indice=0
carattere= None
while indice <= lunghezza_scuola:
    Carattere= nome_scuola[indice]
    indice += 1
    print(Carattere)