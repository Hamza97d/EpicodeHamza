"""Stampare a video tutti e soli gli studenti che frequentano una prima edizione; non tutti i dati potrebbero essere necessari."""

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"]
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend", "Frontend", "Cybersecurity"]
edizioni = [1, 2, 3, 2, 2, 1, 3, 3]

lunghezza_liste = len(studenti)
indice = 0

while indice < lunghezza_liste:
    if edizioni[indice] == 1:
        sel_studente = studenti[indice]
        sel_corso = corsi[indice]
        sel_edizione = edizioni[indice]
        print(sel_studente, sel_corso, sel_edizione)
    indice += 1 
  
