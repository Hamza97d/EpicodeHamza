#Stampare a video tutti i numeri da 0 a 20 utilizzando il costrutto while.

numero_finale= 20
numero= 0

while numero <= numero_finale:
  print(numero)
  numero += 1