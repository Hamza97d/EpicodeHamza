#Calcolare e stampare tutte le potenze di 2 minori di 25000.

n= 2
elevato= 0
potenza= 0

while potenza < 25000:
    potenza= n**elevato
    print(n, "elevato a ",elevato," e uguale a: ", potenza)
    elevato +=1