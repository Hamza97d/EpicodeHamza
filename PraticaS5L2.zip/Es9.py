#Calcolare (ma non stampare) le prime N potenze di K; ognuna di esse andrà memorizzata in coda a una lista. 
#Alla fine, stampare la lista risultante.Proviamo con diversi valori di K, oppure facciamola inserire all'utente.

k= int(input("Inserire K "))
elevato= 0
finale= int(input("Inserire N "))
lista_potenza=[]

while elevato <= finale:
    potenza= k**elevato
    lista_potenza.append(potenza)
    elevato +=1 
print(lista_potenza)
