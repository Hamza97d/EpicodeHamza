#Calcolare e stampare tutte le prime N potenze di 2 utilizzando un ciclo while,
#domandando all'utente di inserire N.

n= 2
elevato= 0
finale= int(input("Inserire N "))

while elevato <= finale:
    potenza= n**elevato
    print(n, "elevato a ",elevato," e uguale a: ", potenza)
    elevato +=1