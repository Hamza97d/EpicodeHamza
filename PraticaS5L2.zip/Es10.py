#Abbiamo una lista con i guadagni degli ultimi 12 mesi 
#calcolare la media dei guadagni e stamparla a video.

guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
lunghezza_guadagni = len(guadagni)
indice = 0
somma_guadagni = 0 

while indice < lunghezza_guadagni:
    numero = guadagni[indice]
    somma_guadagni += numero  
    indice += 1
    

media_guadagni = somma_guadagni / lunghezza_guadagni
print("la media dei guadagni della lista e ", media_guadagni)
