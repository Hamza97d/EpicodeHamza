#suddividere in due squadre

studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry", "Isabelle", "John"]

squadra_pari = []
squadra_dispari = []
indice = 0

while indice < len(studenti):
    nome = studenti[indice]
    if indice % 2 == 0:
        squadra_pari.append(nome)
    else:
        squadra_dispari.append(nome)
    indice += 1

print("Squadra Pari:", squadra_pari)
print("Squadra Dispari:", squadra_dispari)
  
