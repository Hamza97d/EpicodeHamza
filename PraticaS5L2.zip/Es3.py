 #stampare tutte le prime 10 potenze di 2 (e.g., 2⁰, 2¹, 2², …) utilizzando un ciclo while.

n= 2
elevato= 0
finale=10

while elevato <= finale:
    potenza= n**elevato
    print(n, "elevato a ",elevato," e uguale a: ", potenza)
    elevato +=1