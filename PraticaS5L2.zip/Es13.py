"""cambiare il simbolo dell'euro (€) in quello del dollaro ($) per ogni stringa nella lista; il risultato sarà memorizzato in un'altra lista."""

prezzi = ["100 €", "200 €", "500 €", "10 €", "50 €", "70 €"]
lunghezza_prezzi= len(prezzi)
indice= 0
prezzi_convertiti= []
while indice < lunghezza_prezzi:
   a= prezzi[indice]   
   a= a.replace("€", "$")
   prezzi_convertiti.append(a)
   indice +=1

print(prezzi_convertiti)
  
