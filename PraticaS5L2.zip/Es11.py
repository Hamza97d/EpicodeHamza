#codice fiscale detector

lista_cf = ["ABCDEF95G01A123B", "GHIJKL91M02A321C", "MNOPQR89S03A456D", "STUVWX95Z04A654E", "XYZABC01D05A789F", "DEFGHI95J06A987G"]
lunghezza_lista= len(lista_cf)
indice= 0
new_95_list= []
while indice < lunghezza_lista:
  identifier = lista_cf[indice]
  if "95" in identifier:
    new_95_list.append(identifier)
  indice +=1

print(new_95_list)
lunghezza_lista2= len(new_95_list)
indice2=0
while indice2 < lunghezza_lista2:
  seleziona= new_95_list[indice2]
  cognome= seleziona[0:3]
  nome= seleziona[3:6]
  print("nel indice ",indice2, "si trova il cognome ", cognome, "e nome ", nome )
  indice2 += 1
  
